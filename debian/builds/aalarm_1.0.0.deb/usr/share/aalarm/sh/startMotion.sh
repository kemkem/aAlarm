#!/bin/sh

#/etc/init.d/motion start
#service motion start
motion
