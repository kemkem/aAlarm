#!/bin/sh

/etc/init.d/zoneminder start
