--
-- Dumping data for table `aalarm_sensor`
--

LOCK TABLES `aalarm_sensor` WRITE;
/*!40000 ALTER TABLE `aalarm_sensor` DISABLE KEYS */;
INSERT INTO `aalarm_sensor` VALUES (1,1,'Global','Global',0),(2,2,'Door1','Main Door',1),(3,3,'ZoneMinder','Motion',0),(4,3,'MusicPlaylist','Music Playlist',0);
/*!40000 ALTER TABLE `aalarm_sensor` ENABLE KEYS */;
UNLOCK TABLES;

